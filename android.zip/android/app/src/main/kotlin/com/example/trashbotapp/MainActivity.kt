package com.example.trashbotapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
