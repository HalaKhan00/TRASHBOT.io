class RecaptchaResult {
  final String? verificationId;

  RecaptchaResult(this.verificationId);
}
