abstract class Jsonable {
  Future<Map<String, dynamic>> toJson();
}
