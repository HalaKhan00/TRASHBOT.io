//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import desktop_webview_auth

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  DesktopWebviewAuthPlugin.register(with: registry.registrar(forPlugin: "DesktopWebviewAuthPlugin"))
}
