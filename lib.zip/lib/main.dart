import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:firebase_ui_auth/firebase_ui_auth.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:flutter/services.dart';
import 'package:tflite/tflite.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:math';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:google_fonts/google_fonts.dart';
import 'package:audioplayers/audioplayers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  // Obtain a list of the available cameras on the device.
  final cameras = await availableCameras();

  // Get a specific camera from the list of available cameras.
  final firstCamera = cameras.first;

  runApp(MyApp(camera: firstCamera));
}

class MyApp extends StatelessWidget {
  final CameraDescription camera;

  MyApp({Key? key, required this.camera}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SwiperScreen(camera: camera),
    );
  }
}

class SwiperScreen extends StatefulWidget {
  final CameraDescription camera;

  SwiperScreen({Key? key, required this.camera}) : super(key: key);


  @override
  _SwiperScreenState createState() => _SwiperScreenState();
}

class _SwiperScreenState extends State<SwiperScreen> {
  PageController _pageController = PageController();
  int _currentPage = 0;

  List<Widget> _screens = [
    FirstScreen(),
    SecondScreen(),
    ThirdScreen(),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightGreen[50],
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: _screens.length,
              onPageChanged: (index) {
                setState(() {
                  _currentPage = index;
                });
              },
              itemBuilder: (context, index) {
                return _screens[index];
              },
            ),
          ),
          SizedBox(height: 20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: _buildPageIndicator(),
          ),
          SizedBox(height: 20.0),
        ],
      ),
    );
  }

  List<Widget> _buildPageIndicator() {
    List<Widget> indicators = [];
    for (int i = 0; i < _screens.length; i++) {
      indicators.add(
        Container(
          margin: EdgeInsets.symmetric(horizontal: 5.0),
          height: 10.0,
          width: 10.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _currentPage == i ? Colors.green : Colors.grey[400],
          ),
        ),
      );
    }
    return indicators;
  }
}

class FirstScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/calender.png',
            height: 300,
            width: 300,
          ),
          SizedBox(height: 10),
          Text(
            'Collection Calendar',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/sort.png',
            height: 300,
            width: 300,
          ),
          SizedBox(height: 10),
          Text(
            'Sorting Waste',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}

class ThirdScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/clean.png',
            height: 300,
            width: 300,
          ),
          SizedBox(height: 10),
          Text(
            'Clean & Green - PAKISTAN',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 100.0),
          ),
          Container(
            width: MediaQuery.of(context).size.width * 0.6,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SignUpPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                backgroundColor: Colors.lightGreen,
              ),
              child: Text("Let's Do It!"),
            ),
          ),
        ],
      ),
    );
  }
}

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _formKey = GlobalKey<FormState>();
  String password = '';
  String email = '';
  String username = '';
  bool termsAndConditions = false;
  bool hidePassword = true;
  bool hideConfirmPassword = true;

  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<String?> signUp(String email, String password, String username) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      User? firebaseUser = userCredential.user;
      if (firebaseUser != null) {
        await FirebaseFirestore.instance.collection('users').doc(firebaseUser.uid).set({
          'username': username,
          'email': email,
        }, SetOptions(merge: true)).catchError((error) {
          return 'Failed to save user data. Please try again!';
        });
        await _auth.signInWithEmailAndPassword(email: email, password: password);  // Sign in the user
      }
      return null;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        return 'User already exists. Please Login!';
      }
    } catch (e) {
      return 'An error occurred. Please try again!';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightGreen[50],
      appBar: AppBar(
        title: Text('Sign Up'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                TextFormField(
                  controller: usernameController,
                  decoration: InputDecoration(
                    labelText: 'Username',
                    hintText: 'Enter your username',
                  ),
                  validator: RequiredValidator(errorText: 'Username is required'),
                  onSaved: (String? value) {
                    username = value!;
                  },
                ),
                TextFormField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    hintText: 'Enter your email',
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: 'Email is required'),
                    EmailValidator(errorText: 'Enter a valid email address'),
                  ]),
                  onSaved: (String? value) {
                    email = value!;
                  },
                ),
                TextFormField(
                  controller: passwordController,
                  obscureText: hidePassword,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    suffixIcon: IconButton(
                      icon: Icon(
                        hidePassword ? Icons.visibility_off : Icons.visibility,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          hidePassword = !hidePassword;
                        });
                      },
                    ),
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: 'Password is required'),
                    MinLengthValidator(8, errorText: 'Password must be at least 8 digits long'),
                  ]),
                  onSaved: (String? value) {
                    password = value!;
                  },
                ),
                TextFormField(
                  obscureText: hideConfirmPassword,
                  decoration: InputDecoration(
                    labelText: 'Confirm Password',
                    hintText: 'Confirm your password',
                    suffixIcon: IconButton(
                      icon: Icon(
                        hideConfirmPassword ? Icons.visibility_off : Icons.visibility,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          hideConfirmPassword = !hideConfirmPassword;
                        });
                      },
                    ),
                  ),
                  validator: (String? value) {
                    if (value != passwordController.text) {
                      return 'Passwords do not match';
                    }
                  },
                ),
                CheckboxListTile(
                  title: Text("I accept the terms and conditions"),
                  value: termsAndConditions,
                  onChanged: (newValue) {
                    setState(() {
                      termsAndConditions = newValue!;
                    });
                  },
                  controlAffinity: ListTileControlAffinity.leading,
                ),
            Container(
              width: MediaQuery.of(context).size.width * 0.6,
              child: ElevatedButton(
                onPressed: termsAndConditions ? () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    String? result = await signUp(email, password, username);
                    if (result != null) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
                    } else {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => MenuScreen()));
                    }
                  }
                } : null,
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  backgroundColor: termsAndConditions ? Colors.lightGreen : Colors.grey,
                ),
                child: Text('Join TrashBot'),
              ),
            ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => LogInScreen()));
                  },
                  child: Text(
                    'Already a member? LogIn',
                    style: TextStyle(color: Colors.lightGreen),
                  ),
                ),

              ],

          ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    usernameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}

class AddressForm extends StatefulWidget {
  @override
  _AddressFormState createState() => _AddressFormState();
}

class _AddressFormState extends State<AddressForm> {
  final _formKey = GlobalKey<FormState>();
  bool isFormFilled = false;

  void _validateForm() {
    setState(() {
      isFormFilled = _formKey.currentState!.validate();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightGreen[50],
      appBar: AppBar(
        backgroundColor: Colors.lightGreen,
        title: Text('Address Form'),
      ),
      body: Form(
        key: _formKey,
        onChanged: _validateForm,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: <Widget>[
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'House/Apartment/Building',
                  hintText: 'Enter House/Apartment/Building',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter House/Apartment/Building';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Street/Lane',
                  hintText: 'Enter Street/Lane',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Street/Lane';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Colony/Area',
                  hintText: 'Enter Colony/Area',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Colony/Area';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'City',
                  hintText: 'Enter City',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter City';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Contact Number',
                  hintText: 'Enter Contact Number',
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Contact Number';
                  }
                  return null;
                },
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.6,
                child: ElevatedButton(
                  onPressed: isFormFilled ? () {
                    Navigator.pop(context, true);
                  } : null,
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    backgroundColor: isFormFilled ? Colors.lightGreen : Colors.grey,
                  ),
                  child: Text('Let\'s Go'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LogInScreen extends StatefulWidget {
  @override
  _LogInScreenState createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightGreen[50],
      appBar: AppBar(
        title: Text('Welcome Back Homie'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                // Email Field
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Email',
                    hintText: 'Enter your email',
                  ),
                  validator: RequiredValidator(errorText: 'Email is required'),
                  onSaved: (String? value) {
                    email = value!;
                  },
                ),
                // Password Field
                TextFormField(
                  obscureText: _obscureText,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    suffixIcon: IconButton(
                      icon: Icon(_obscureText ? Icons.visibility_off : Icons.visibility,color: Colors.grey),
                      onPressed: () {
                        setState(() {
                          _obscureText = !_obscureText;
                        });
                      },
                    ),
                  ),
                  validator: RequiredValidator(errorText: 'Password is required'),
                  onSaved: (String? value) {
                    password = value!;
                  },
                ),
                // Log In Button
                Container(
                  width: MediaQuery.of(context).size.width * 0.6,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        try {
                          UserCredential userCredential = await FirebaseAuth.instance
                              .signInWithEmailAndPassword(email: email, password: password);
                          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => MenuScreen()));
                        } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('You\'re a new user. Please Sign Up')));
                        }
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      backgroundColor: Colors.lightGreen,
                    ),
                    child: Text('Welcome!'),
                  ),
                ),
                // Not a member? Sign Up Option
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUpPage()),
                    );
                  },
                  child: Text(
                    'Not a member? Sign Up',
                    style: TextStyle(color: Colors.lightGreen),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MenuScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu Screen'),
        backgroundColor: Colors.lightGreen,
      ),
      backgroundColor: Colors.lightGreen[50],
      body: Padding(
        padding: const EdgeInsets.only(top: 40.0), // adjust the size as needed
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            IconMenu(Icons.dashboard, 'Dashboard', context, DashboardScreen()),
            IconMenu(Icons.insights, 'Insights', context, InsightsScreen()),
            IconMenu(Icons.article, 'News', context, NewsScreen()),
            IconMenu(Icons.report, 'Reports', context, ReportsScreen()),
            IconMenu(Icons.filter_center_focus, 'T-Scan', context, ScanScreen()),
            IconMenu(Icons.settings, 'Settings', context, SettingsScreen()),
          ],
        ),
      ),
    );
  }
}

class IconMenu extends StatelessWidget {
  final IconData icon;
  final String title;
  final BuildContext parentContext;
  final Widget destination;

  IconMenu(this.icon, this.title, this.parentContext, this.destination);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          parentContext,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
      child: Column(
        children: <Widget>[
          Icon(icon, size: 70.0, color: Colors.lightGreen),
          SizedBox(height: 10.0),
          Text(
            title,
            style: TextStyle(fontSize: 18.0),
          ),
        ],
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Screen'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Center(
        child: Text('Hi! I am TRASHBOT'),
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<String> tips = [
    "Tip: Separate waste at the source.",
    "Tip: Use separate bins for recyclable and non-recyclable wastes.",
    "Tip: Try to reduce waste by reusing items.",
    "Tip: Composting can reduce organic waste and benefit your garden.",
    "Tip: Avoid buying items with too much packaging.",
    "Tip: Donate or sell items that you no longer need instead of throwing them away.",
    "Tip: Use a reusable shopping bag to reduce plastic waste.",
    "Tip: Buy products in bulk to reduce packaging waste.",
    "Tip: Use a refillable water bottle instead of buying single-use bottles.",
    "Tip: Choose products with less packaging to reduce waste.",
    "Tip: Practice recycling in your home and workplace.",
    "Tip: Use paper bags instead of plastic bags.",
    "Tip: Keep your organic waste for composting; it can serve as an excellent fertilizer for your plants.",
    "Tip: Dispose of electronic waste at designated collection centers.",
    "Tip: Reuse items like glass jars and containers for storage.",
    "Tip: Consider repairing or refurbishing old furniture instead of disposing of it.",
    "Did you know? An average person generates over 4 pounds of trash every day and about 1.5 tons of solid waste per year.",
    "Did you know? Recycling, reusing, and composting create 6 to 10 times as many jobs as waste incineration and landfills.",
    "Did you know? It takes 500 years for average sized plastic water bottles to fully decompose.",
    "Did you know? It takes a 15-year-old tree to produce 700 grocery bags.",
    "Did you know? More than 60% of the rubbish that ends up in trash bins could be recycled.",
    "Did you know? The energy saved from recycling one glass bottle can power an old 100-watt light bulb for four hours.",
    "Did you know? Around 80% of a vehicle can be recycled.",
    "Did you know? More than 1/3 of all fiber used to make paper comes from recycled paper.",
    "Did you know? Almost 40% of the world's waste is dumped in landfill sites.",
  ];
  String currentTip = "";

  @override
  void initState() {
    super.initState();
    currentTip = getRandomTip(); // Get a random tip when the screen is loaded
  }

  String getRandomTip() {
    final random = Random();
    return tips[random.nextInt(tips.length)];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(200.0),
        child: Container(
          color: Colors.lightGreen,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/default_avatar.jpg'),
              ),
              SizedBox(height: 8),
              Text(
                'Rose Park',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Container(
        color: Colors.lightGreen[100],
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 30, bottom: 20),
              child: FractionallySizedBox(
                widthFactor: 0.6,
                child: ElevatedButton(
                  onPressed: () async {
                    final cameras = await availableCameras();
                    final firstCamera = cameras.first;

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CameraScreen(camera: firstCamera),
                      ),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Begin Segregation',
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.white,
                        ),),
                      SizedBox(width: 10),
                      Icon(Icons.camera_enhance),
                    ],
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightGreen,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    minimumSize: Size(double.infinity, 50),
                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () async {
                const url = 'https://www.google.com/maps';
                if (await canLaunch(url)) {
                  await launch(url);
                } else {
                  throw 'Could not launch $url';
                }
              },
              child: optionButton(Icons.location_on, 'Location'),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UserListScreen(),
                  ),
                );
              },
              child: optionButton(Icons.people, 'Community'),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ScheduleBinScreen(),
                  ),
                );
              },
              child: optionButton(Icons.delete, 'Schedule Bin'),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.lightGreen[50],
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.lightbulb_outline, size: 40,
                            color: Colors.lightGreen),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            currentTip,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget optionButton(IconData icon, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 40.0),
      child: Row(
        children: [
          Icon(icon, size: 40, color: Colors.lightGreen),
          SizedBox(width: 8),
          Text(label,
            style: TextStyle(
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }
}

class CameraScreen extends StatefulWidget {
  final CameraDescription camera;

  const CameraScreen({
    Key? key,
    required this.camera,
  }) : super(key: key);

  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  Interpreter? _interpreter;
  bool isDetecting = false;

  @override
  void initState() {
    super.initState();
    _loadModel();
    _controller = CameraController(widget.camera, ResolutionPreset.high);
    _initializeControllerFuture = _controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});

      _controller.startImageStream((CameraImage img) {
        if (isDetecting) return;

        isDetecting = true;


        Tflite.runModelOnFrame(
          bytesList: img.planes.map((plane) {
            return plane.bytes;
          }).toList(),
          imageHeight: img.height,
          imageWidth: img.width,
          imageMean: 127.5,   // depending on your model
          imageStd: 127.5,    // depending on your model
          rotation: 90,       // depend on your device camera's sensor orientation
          numResults: 2,      // the number of output you want
          threshold: 0.1,     // the threshold for the output
          asynch: true,
        ).then((recognitions) {
          print('Recognitions: $recognitions');
          // Do something with the recognitions
          // Don't forget to call setState if the UI needs to be updated

          isDetecting = false;
        });
      });
    });
  }

  Future<void> _loadModel() async {
    var modelFile = await rootBundle.load('assets/model.tflite');
    _interpreter = await Interpreter.fromBuffer(modelFile.buffer.asUint8List());
  }

  @override
  void dispose() {
    _controller.stopImageStream(); // Stop the image stream
    _controller.dispose();
    Tflite.close(); // Close the TFLite interpreter
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Camera Screen')),
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CameraPreview(_controller);
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}

class UserListScreen extends StatefulWidget {
  @override
  _UserListScreenState createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final _scrollController = ScrollController();
  DocumentSnapshot? _lastDocument;
  List<DocumentSnapshot> _users = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadMoreUsers();
  }

  void _loadMoreUsers() async {
    Query query = _db.collection('users').orderBy('username').limit(10);
    if (_lastDocument != null) {
      query = query.startAfterDocument(_lastDocument!);
    }

    if (!_isLoading) {
      setState(() {
        _isLoading = true;
      });

      QuerySnapshot querySnapshot = await query.get();
      if (querySnapshot.docs.isNotEmpty) {
        _lastDocument = querySnapshot.docs[querySnapshot.docs.length - 1];
        _users.addAll(querySnapshot.docs);
      }

      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Community'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Container(
        color: Colors.lightGreen[100],
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: _users.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(_users[index]['profilePicture']),
                    ),
                    title: Text(_users[index]['username']),
                  );
                },
              ),
            ),
            if (_isLoading)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircularProgressIndicator(),
              ),
            ElevatedButton(
              onPressed: _loadMoreUsers,
              child: Text('Show more users'),
              style: ElevatedButton.styleFrom(
                primary: Colors.lightGreen,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ScheduleBinScreen extends StatefulWidget {
  @override
  _ScheduleBinScreenState createState() => _ScheduleBinScreenState();
}

class _ScheduleBinScreenState extends State<ScheduleBinScreen> {
  DateTime _date = DateTime.now();
  TimeOfDay _time = TimeOfDay.now();
  bool _isAllTasksCompleted = false;

  Future<void> _selectDate(BuildContext context) async {
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2025),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.lightGreen,
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );

    if (selectedDate != null) {
      setState(() {
        _date = selectedDate;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final selectedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.lightGreen,
            ),
          ),
          child: child!,
        );
      },
    );

    if (selectedTime != null) {
      setState(() {
        _time = selectedTime;
      });
    }
  }

  void _openConfirmationScreen() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ConfirmationScreen()),
    );

    if (result != null) {
      setState(() {
        _isAllTasksCompleted = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Schedule Bin'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.4,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/trashcan_image.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'You are welcome buddy',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _openConfirmationScreen,
            child: Text('Schedule Bin'),
            style: ElevatedButton.styleFrom(
              primary: Colors.lightGreen,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          SizedBox(height: 20),
          TextButton.icon(
            onPressed: _isAllTasksCompleted ? () => _selectDate(context) : null,
            icon: Icon(Icons.date_range),
            label: Text(
              'Select Day: ${_date.year}-${_date.month}-${_date.day}',
            ),
            style: TextButton.styleFrom(
              primary: Colors.white,
              backgroundColor: _isAllTasksCompleted
                  ? Colors.lightGreen
                  : Colors.grey, // Disable the button if tasks are not completed
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          SizedBox(height: 20),
          TextButton.icon(
            onPressed: _isAllTasksCompleted ? () => _selectTime(context) : null,
            icon: Icon(Icons.timer),
            label: Text(
              'Select Time: ${_time.format(context)}',
            ),
            style: TextButton.styleFrom(
              primary: Colors.white,
              backgroundColor: _isAllTasksCompleted
                  ? Colors.lightGreen
                  : Colors.grey, // Disable the button if tasks are not completed
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
          SizedBox(height: 20),
          InkWell(
            onTap: () async {
              const url = 'https://www.google.com';
              if (await canLaunch(url)) {
                await launch(url);
              } else {
                throw 'Could not launch $url';
              }
            },
            child: Text(
              'For query, contact the company',
              style: TextStyle(color: Colors.lightGreen),
            ),
          ),
        ],
      ),
    );
  }
}

class ConfirmationScreen extends StatefulWidget {
  @override
  _ConfirmationScreenState createState() => _ConfirmationScreenState();
}

class _ConfirmationScreenState extends State<ConfirmationScreen> {
  bool _acceptedTnC = false;
  bool _addedNumber = false;
  bool _addedAddress = false;
  bool _sureToSchedule = false;

  void _openTermsAndConditionsScreen() {
    // Open the Terms and Conditions screen
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Confirmation'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Column(
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.01), // Adjust the height as desired
          Image.asset(
            'assets/TNC.png',
            height: 250, // Adjust the height as desired
            width: 250, // Adjust the width as desired
          ),
          SizedBox(height: 20), // Adjust the spacing as desired
          CheckboxListTile(
            title: GestureDetector(
              onTap: _openTermsAndConditionsScreen,
              child: Theme(
                data: Theme.of(context).copyWith(
                  textTheme: Theme.of(context).textTheme.copyWith(
                    bodyText2: TextStyle(
                      decoration: TextDecoration.underline,
                      decorationColor: Colors.lightGreen, // Set the underline color to light green
                      // Add any other desired text styles
                    ),
                  ),
                ),
                child: RichText(
                  text: TextSpan(
                    text: 'Do you agree to the ',
                    style: DefaultTextStyle.of(context).style.copyWith(
                      fontSize: 15,
                      color: Colors.black,
                    ),
                    children: <TextSpan>[
                      TextSpan(
                        text: 'Terms and Conditions',
                        style: TextStyle(
                          color: Colors.lightGreen,
                        ),
                      ),
                      TextSpan(text: '?'),
                    ],
                  ),
                ),
              ),
            ),
            value: _acceptedTnC,
            onChanged: (newValue) {
              setState(() {
                _acceptedTnC = newValue!;
              });
            },
            activeColor: Colors.lightGreen,
          ),
          CheckboxListTile(
            title: Text('Did you add your active cell phone number?'),
            value: _addedNumber,
            onChanged: (newValue) {
              setState(() {
                _addedNumber = newValue!;
              });
            },
            activeColor: Colors.lightGreen,
          ),
          CheckboxListTile(
            title: Text('Did you add your present address?'),
            value: _addedAddress,
            onChanged: (newValue) {
              setState(() {
                _addedAddress = newValue!;
              });
            },
            activeColor: Colors.lightGreen,
          ),
          CheckboxListTile(
            title: Text('Are you sure you want to schedule the Bin?'),
            value: _sureToSchedule,
            onChanged: (newValue) {
              setState(() {
                _sureToSchedule = newValue!;
              });
            },
            activeColor: Colors.lightGreen,
          ),
          SizedBox(height: 20), // Adjust the spacing as desired
          Container(
            width: MediaQuery.of(context).size.width * 0.6,
            child: ElevatedButton(
              onPressed: _acceptedTnC && _addedNumber && _addedAddress && _sureToSchedule
                  ? () {
                // Go back to Schedule Bin screen with true as all conditions are met
                Navigator.pop(context, true);
              }
                  : null,
              child: Text('Done'),
              style: ElevatedButton.styleFrom(
                primary: Colors.lightGreen,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                onSurface: Colors.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Waste {
  final String type;
  int amount;

  Waste(this.type, this.amount);
}

class InsightsScreen extends StatefulWidget {
  @override
  _InsightsScreenState createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  DateTime? startTime;
  DateTime? endTime;
  List<Waste> wasteData = [
    Waste('glass', 0),
    Waste('paper', 0),
    Waste('metal', 0),
    Waste('plastic', 0),
  ];

  void incrementWasteAmount(String type) {
    setState(() {
      wasteData.firstWhere((waste) => waste.type == type).amount++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insights'),
        backgroundColor: Colors.lightGreen,
      ),
      backgroundColor: Colors.lightGreen[50],
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your progress so far...',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
            ),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    startTime = DateTime.now();
                  });
                },
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6, // 60% of screen width
                  child: Center(child: Text('Start Segregation')),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Colors.lightGreen,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                ),
              ),
            ),
            if (startTime != null)
              Center(
                child: Container(
                  padding: EdgeInsets.all(8.0),
                  color: Colors.lightGreen[100],
                  child: Text(
                    'Started at: ${DateFormat('yyyy-MM-dd – kk:mm').format(startTime!)}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            SizedBox(height: 10.0),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    endTime = DateTime.now();
                  });
                },
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6, // 60% of screen width
                  child: Center(child: Text('End Segregation')),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Colors.lightGreen,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                ),
              ),
            ),
            if (endTime != null)
              Center(
                child: Container(
                  padding: EdgeInsets.all(8.0),
                  color: Colors.lightGreen[100],
                  child: Text(
                    'Ended at: ${DateFormat('yyyy-MM-dd – kk:mm').format(endTime!)}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            SizedBox(height: 20.0),
            ...wasteData.map((waste) => Column(
              children: [
                Text(waste.type),
                LinearProgressIndicator(
                  value: waste.amount / 100,
                  color: Colors.lightGreen,
                  backgroundColor: Colors.lightGreen[100],
                ),
                Center(
                  child: ElevatedButton(
                    onPressed: () => incrementWasteAmount(waste.type),
                    child: Text('Add ${waste.type} waste'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.lightGreen,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                    ),
                  ),
                ),
              ],
            )),
          ],
        ),
      ),
    );
  }
}

//a8a58d3dfa8accc1983e5816f3fd72c3

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${this.substring(1)}";
  }
}

class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  List<String> categories = ['health', 'science', 'technology'];
  String selectedCategory = 'health';
  List<dynamic> newsList = []; // store your news data here

  @override
  void initState() {
    super.initState();
    fetchNews(selectedCategory); // Fetch news data when the screen is loaded
  }

  Future<void> fetchNews(String category) async {
    String url =
        'https://gnews.io/api/v4/top-headlines?token=a8a58d3dfa8accc1983e5816f3fd72c3&lang=en&topic=$category';
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      setState(() {
        newsList = json.decode(response.body)['articles'];
      });
    } else {
      print('Failed to load news');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('News'),
        backgroundColor: Colors.lightGreen,
      ),
      backgroundColor: Colors.lightGreen[50],
      body: Column(
        children: [
          SizedBox(height: 20.0),
          Container(
            height: 50.0,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10.0),
                  child: FilterChip(
                    label: Text(categories[index].capitalize()),
                    selected: selectedCategory == categories[index],
                    onSelected: (bool selected) {
                      setState(() {
                        selectedCategory = categories[index];
                      });
                      fetchNews(selectedCategory); // Fetch news data when a new category is selected
                    },
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(10.0),
              child: ListView.builder(
                itemCount: newsList.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: (newsList[index]['image'] != null) ? Image.network(newsList[index]['image']) : Container(), // handle null image
                      title: Text(newsList[index]['title']),
                      subtitle: Text(newsList[index]['description']),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ReportsScreen extends StatefulWidget {
  @override
  _ReportsScreenState createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  late DateTime _focusedDay;
  DateTime? _selectedDay;

  // Dummy data for testing purpose, replace it with actual data from InsightsScreen
  List<Map<String, dynamic>> wasteData = [
    {'type': 'glass', 'amount': 0},
    {'type': 'paper', 'amount': 0},
    {'type': 'metal', 'amount': 0},
    {'type': 'plastic', 'amount': 0},
  ];

  _ReportsScreenState() {
    DateTime firstDay = DateTime.utc(2023, 10, 16);
    DateTime now = DateTime.now();
    if (now.isBefore(firstDay)) {
      _focusedDay = firstDay;
    } else {
      _focusedDay = now;
    }
  }

  void displayReport() {
  }

  void downloadReport() {
    // Implement your logic to download report
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Center(
          child: pw.Text("Hello World", style: pw.TextStyle(fontSize: 40)),
        ),
      ),
    );
    Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Your Waste Report"),
        backgroundColor: Colors.lightGreen,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(height: 20),
            TableCalendar(
              firstDay: DateTime.utc(2023, 10, 16),
              lastDay: DateTime.utc(2030, 3, 14),
              focusedDay: _focusedDay,
              calendarFormat: _calendarFormat,
              selectedDayPredicate: (day) {
                return isSameDay(_selectedDay, day);
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });
              },
              onPageChanged: (focusedDay) {
                setState(() {
                  _focusedDay = focusedDay;
                });
              },
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: displayReport,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6, // 60% of screen width
                  child: Center(child: Text('Display Report')),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Colors.lightGreen,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),
            Center(
              child: ElevatedButton(
                onPressed: downloadReport,
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.6, // 60% of screen width
                  child: Center(child: Text('Download Report')),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Colors.lightGreen,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ScanScreen extends StatefulWidget {
  @override
  _ScanScreenState createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen>  {
  int points = 0;

  void scanObject() async {
      try {
        InterpreterOptions interpreterOptions = InterpreterOptions();
        var interpreter = await Interpreter.fromAsset('model.tflite', options: interpreterOptions);
        // Prepare your input. For example, you may have an image. You should preprocess it to match your model's input.
        // Call interpreter.run(input, output) to make inference.
        // Process the result. For example, you might want to update the `points` based on the inference result.
        // Call setState to update your UI.
      } catch (e) {
        print('Error loading model: $e');
      }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('T-Scan'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Expanded(
              flex: 5,
              child: Container(
                child: Image.asset('assets/scan.png'),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: scanObject,
              style: ElevatedButton.styleFrom(
                primary: Colors.lightGreen,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.6, // 60% of the screen width
                child: Center(
                  child: Text(
                    'Quick Scan',
                    style: TextStyle(
                      fontSize: 16.0,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10), // Added SizedBox for spacing
            Text(
              'Scan your object and get points!',
              style: TextStyle(
                fontSize: 14.0,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              flex: 1,
              child: points > 0
                  ? Container(
                padding: EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                  color: Colors.lightGreen,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Text(
                  'You have been awarded $points points!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.0,
                  ),
                ),
              )
                  : SizedBox(),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Container(
        color: Colors.lightGreen[50],
        child: ListView(
          padding: EdgeInsets.all(10),  // Adding padding to the ListView
          children: <Widget>[
            Image.asset('assets/settings1.png'),  // Illustration Image
            SizedBox(height: 10),  // Adding space between the illustration and user profile
            Container(
              color: Colors.white,
              child: ListTile(
                leading: Icon(Icons.person, color: Colors.lightGreen),
                title: Text('User Profile', style: TextStyle(color: Colors.black)),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => UserProfileScreen()),
                  );
                },
              ),
            ),
            SizedBox(height: 10),  // Adding space between user profile and Help
            Container(
              color: Colors.white,
              child: ListTile(
                leading: Icon(Icons.help, color: Colors.lightGreen),
                title: Text('Help', style: TextStyle(color: Colors.black)),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HelpScreen()),
                  );
                },
              ),
            ),
            SizedBox(height: 10),  // Adding space between Help and logout
            Container(
              color: Colors.white,
              child: ListTile(
                leading: Icon(Icons.logout, color: Colors.lightGreen),
                title: Text('Log Out', style: TextStyle(color: Colors.black)),
                onTap: () async {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LogInScreen()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class UserProfileScreen extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final User? user = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return Container(); // You should handle this properly.
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('User Profile'),
        backgroundColor: Colors.lightGreen,
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.lightGreen[50],
          child: FutureBuilder<DocumentSnapshot>(
            future: _firestore.collection('users').doc(user!.uid).get(),
            builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Text("Error: ${snapshot.error}");
              } else if (snapshot.hasData && snapshot.data!.data() != null) {
                Map<String, dynamic> userData = snapshot.data!.data() as Map<String, dynamic>;

                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Image.asset(
                          'assets/profile.png', // replace with your illustration path
                          height: MediaQuery.of(context).size.height / 3, // adjust size as needed
                        ),
                      ),
                      SizedBox(height: 20),
                      Text('Username: ${userData['username'] ?? 'N/A'}',
                          style: GoogleFonts.pacifico(fontSize: 16, color: Colors.black)),
                      SizedBox(height: 10),
                      Text('Email: ${userData['email'] ?? 'N/A'}',
                          style: GoogleFonts.pacifico(fontSize: 16, color: Colors.black)),
                    ],
                  ),
                );
              } else {
                return Text("No data available"); // handle no data scenario
              }
            },
          ),
        ),
      ),
    );
  }
}

class HelpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Help'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height, // full height of the screen
        width: MediaQuery.of(context).size.width, // full width of the screen
        color: Colors.lightGreen[50],
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: <Widget>[
              SizedBox(height: 30),  // Adding space from top
              Text(
                "For assistance, please contact:",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 30),  // Adding space between text and emails
              emailText("halaalikhan@gmail.com"),
              SizedBox(height: 20),  // Adding space between emails
              emailText("mahrukhalikhan1311@gmail.com"),
              SizedBox(height: 20),  // Adding space between emails
              emailText("arshiyaasaleem@gmail.com"),
            ],
          ),
        ),
      ),
    );
  }

  Widget emailText(String email) {
    return GestureDetector(
      child: Text(
        email,
        style: TextStyle(
          color: Colors.lightGreen,
          fontSize: 20,
          fontStyle: FontStyle.italic,
        ),
      ),
      onTap: () async {
        final Uri _emailLaunchUri = Uri(
          scheme: 'mailto',
          path: email,
        );
        if (await canLaunch(_emailLaunchUri.toString())) {
          await launch(_emailLaunchUri.toString());
        } else {
          throw 'Could not launch $_emailLaunchUri';
        }
      },
    );
  }
}
